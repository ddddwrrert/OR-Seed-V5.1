"""OR-Seed feedback modules."""
