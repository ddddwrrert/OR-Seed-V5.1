"""OR-Seed budget modules."""
