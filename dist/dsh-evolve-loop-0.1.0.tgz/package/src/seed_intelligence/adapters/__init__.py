"""OR-Seed adapters modules."""
