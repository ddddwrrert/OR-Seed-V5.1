"""OR-Seed discovery modules."""
