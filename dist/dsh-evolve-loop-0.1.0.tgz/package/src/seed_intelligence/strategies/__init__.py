"""OR-Seed strategies modules."""
