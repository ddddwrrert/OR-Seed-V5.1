"""OR-Seed dynamic modules."""
